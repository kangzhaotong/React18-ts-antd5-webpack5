import React, { useState, useMemo, useCallback } from 'react'
// import { flushSync } from 'react-dom'
import { Input, Button } from 'antd'
import './App.css'

// interface params {
//   data: string
//   handelClick: () => void
// }

const Child = ({ data, handelClick }) => {
  console.log('child')
  return <Button onClick={() => handelClick()}>{data}</Button>
}

const UseMemoChild = React.memo(Child)
const App = () => {
  console.log('app')
  const [name, setName] = useState('aaaa')
  const [value, setValue] = useState('')
  const [isTransition, setTransion] = useState(false)
  // useEffect(() => {
  // }, [])
  const data = useMemo(() => name, [name])
  const handelInputChange = (val) => {
    console.log(val, 'aaaa')
    setValue(val.target.value)
  }
  const changeName = useCallback(() => setName(name + 'haizi'), [name])

  return (
    <div className="App">
      <div>
        <span>{value}</span>
        <Button onClick={() => setTransion(!isTransition)}>{isTransition ? 'transition' : 'normal'} </Button>
        <Input onChange={(val) => handelInputChange(val)} />
        <UseMemoChild data={data} handelClick={changeName} />
      </div>
    </div>
  )
}

export default App
