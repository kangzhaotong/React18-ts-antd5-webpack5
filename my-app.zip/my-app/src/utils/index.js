function currFunc() {
    let newArgs = [...arguments]
    // console.log(newArgs, [...arguments], '11111')
    function innerFun() {
        // console.log(newArgs, [...arguments], '2222222')
        newArgs.push(...arguments)
        // console.log(newArgs, '33333333')
        return innerFun;
    }
    innerFun.valueOf = () => newArgs.reduce((a, b) => a + b)
    return innerFun
}
console.log(currFunc(4)(5, 6)(3)(8, 9).valueOf());
const PENDDING = 'PENDDING'
const REJECTED = 'REJECTED'
const FULFILLED = 'FULFILLED'
class Promise {
    constructor(executer) {
        // debugger
        this.state = PENDDING;
        this.val = undefined;
        this.reason = undefined;
        const resolve = (value) => {
            if (this.state === PENDDING) {
                this.state = FULFILLED;
                this.val = value
            }
        }
        const reject = (reason) => {
            if (this.state === PENDDING) {
                this.state = REJECTED;
                this.reason = reason
            }
        }
        try {
            executer(resolve, reject)
        } catch (e) {
            throw new Error("执行失败")
        }
    }
    then(onFullfilled, onReject) {
        if (this.state === FULFILLED) {
            onFullfilled(this.val)
        }
        if (this.state === REJECTED) {
            onReject(this.reason)
        }
    }
}
const promise = new Promise((resolve, reject) => {
    // 传入一个异步操作
    resolve('成功');
}).then(
    (data) => {
        console.log('success', data)
    },
    (err) => {
        console.log('faild', err)
    }
)

const LETTERS = /[a-z0-9]/
const currentToken = ''
const tokens = []
function emit(token) {
    currentToken.type = ""
    currentToken.value = ""
    tokens.push(token)
}
function start (name){
    console.log(name, 'lllllllllllllllllll')
    if (name === '<') {
        emit({ type: 'leftParaent', value: '<' })
        return dealParaentFunc;
    }
    throw new Error("出错")
}
function dealParaentFunc(char) {
    console.log('first')
    if (LETTERS.test(char)) {
        currentToken.type = 'JSXIdentifier';
        currentToken.vaule += char;
        return jsxIdentifier;
    }
}
function jsxIdentifier(char) {
    if (LETTERS.test(char)) {
        currentToken.vaule += char;
        return jsxIdentifier;
    } else if(char === ''){
      emit(currentToken)
    }
}
function testFunc(stringCode) {
    // debugger
/*  */
    let state = start
    for (let item of stringCode) {
       if(state) state = state(item)
    //  start(item)
    }
    return tokens
}
testFunc("<h1 id='asda' class='name'> <span>sadasda</span></h1>")
function animal () {
    console.log('I`m a human')
}

let child = new animal();
console.log(child.__proto__, animal.prototype,animal.prototype.constructor,Object.prototype, Object.__proto__, 'ceshiceshi')
let a ={};
let b = {name:1, age:12}
let c = {height:1.9, weghit: 120}
let d = Object.assign(a,b,c)
console.log(d)