// function creatError(): never {
//     console.log(1);
//     throw new Error("baochuo")
// }
enum Color {
    red,
    green
}
console.log(Color.green, Color.red, 'ceshi');